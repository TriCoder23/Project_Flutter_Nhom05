import 'package:flutter/material.dart';

import 'shoe.dart';

class Cart extends ChangeNotifier{
  //list of shoes for sales
  List<Shoe> shoeShop = [
    Shoe(
        name: 'Jordan',
        price: '130',
        imagePath: 'lib/images/Jordan.png',
        description: 'The forward-thinking design of his lastest signature shoe',
    ),

    Shoe(
        name: 'Lebron',
        price: '210',
        imagePath: 'lib/images/Lebron.png',
        description: 'With its extra-durable rubber outsole, this version gives you traction for outdoor courts',
    ),

    Shoe(
        name: 'AF1',
        price: '120',
        imagePath: 'lib/images/AF1.png',
        description: 'Durably stitched overlays, clean finishes and the perfect amount of flash to make you shine',
    ),

    Shoe(
        name: 'Vapor',
        price: '300',
        imagePath: 'lib/images/Vapor.png',
        description: 'This special version encourages you to chase your own destiny with all-out optimism')
  ];
  //list of items in user cart
  List<Shoe> userCart = [];
  //get list of item for sale
  List<Shoe> getShoeList(){
    return shoeShop;
  }

  //get cart
  List<Shoe> getUserCart(){
    return userCart;
  }
  //add items to cart
  void addItemToCart(Shoe shoe){
    userCart.add(shoe);
    notifyListeners();
  }
  //remove item from cart
  void removeItemFromCart(Shoe shoe){
    userCart.remove(shoe);
    notifyListeners();
  }
}